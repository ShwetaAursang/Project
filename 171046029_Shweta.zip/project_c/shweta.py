import MySQLdb
import pandas as pd 
import numpy as np 
import json
#import matplotlib.pyplot as plt
# Connect
db = MySQLdb.connect(host="localhost",
                     user="root",
                     passwd="shwetha",
                     db="mortality")

cursor = db.cursor()
cur = db.cursor()
# this is the query we will be making

print("Disease names with their id's")
print("Preterm-1")
print("Pertussis-2")
print("Intrapartum-3")
print("Sepsis-4")
print("Tetanus-5")
print("Congenital-6")
print("Pneumonia-7")
print("Diarrhoea-8")
print("Malaria-9")
print("Aids-10")
print("Measles-11")
print("Injury-12")
print("Meningitis-13")
print("Other-14")
did=raw_input("Enter a disease id as above")
#print(did)
print("Year(2015 Or 2000)")
year=raw_input("Enter a year")
query = "SELECT LOWER(country.cshort),Disease_Rates.rate_of_deaths_ FROM country INNER JOIN Disease_Rates ON country.cid = Disease_Rates.cid INNER JOIN disease ON disease.did = Disease_Rates.did WHERE Disease_Rates.year=%s AND disease.did=%s"% (year,did)
#params=(did,year)
# execute the query   ,params
cur.execute(query)
# retrieve the whole result set
rows= cur.fetchall()
json_output = json.dumps(rows)
filename = 'country1.json'
f = open(filename,'w+')
f.write(json_output)
f.close()

