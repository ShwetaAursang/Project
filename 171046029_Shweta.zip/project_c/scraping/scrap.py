import urllib2
#from random import randrange
z=0
#yearurl=""
#monthurl=""
#dayurl=""
url1='http://www.thehindu.com/archive/print/'
#this for loop gets the day,month,and year from 2010 to 2017
for i in range(2010,2018):
	yearurl = url1+str(i)+"/"
	for j in range(1,13):
		monthurl =yearurl+str(j)+"/"
		for k in range(1,31):
			dayurl=monthurl+str(k)+"/"			
			z+=1			
			try:
				url=urllib2.urlopen(dayurl+'#FrontPage')
				page=url.read()
			except:
				print "error"
				print url
				continue
			from bs4 import BeautifulSoup #beautiful soup library is used to scrap
			f=open('test6.txt','a') #file1 is opened
			f2=open('test7.txt','a')#file2 is opened
			for ul in BeautifulSoup(page).find_all('ul',{'class':'archive-list'}):
				for a in ul.find_all('a'):				    					
					out=a.text.encode('utf-8')
					f2.write(out + '\n')	#all headlines of a page are written on to file2			
					key=['mortality','child','infant','hygiene'] #key words based on search is done 										
					if any(x in str(out).lower().split() for x in key):
						f.write(out + '\n') #from file2 based on key words lines are written to the file1
						z+=1
			f.close() #file1 close
			f2.close() #file2 close
