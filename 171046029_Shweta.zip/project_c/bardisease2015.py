import MySQLdb
import pandas as pd 
import numpy as np 
import json
#import matplotlib.pyplot as plt
# Connect
db = MySQLdb.connect(host="localhost",
                     user="root",
                     passwd="shwetha",
                     db="mortality")

cursor = db.cursor()
cur = db.cursor()
# this is the query we will be making
query =  "SELECT Disease_Rates.rate_of_deaths_ FROM Disease_Rates INNER JOIN country ON country.cid = Disease_Rates.cid INNER JOIN disease ON disease.did = Disease_Rates.did WHERE Disease_Rates.year=2015 AND disease.did=1"

# execute the query   ,params
cur.execute(query)
# retrieve the whole result set
rows= cur.fetchall()
df=pd.DataFrame([[j for j in i] for i in rows])
print df
list=[rows]
val=list.append(rows)
#print rows
#for r in rows:
print val
json_output = json.dumps(rows)
filename = 'bardisease2015.txt'
f = open(filename,'w+')
f.write(json_output)
f.close()

