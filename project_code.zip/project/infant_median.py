import MySQLdb
import pandas as pd 
import numpy as np 
import json
import matplotlib.pyplot as plt
# Connect
db = MySQLdb.connect(host="localhost",
                     user="root",
                     passwd="shwetha",
                     db="mortality")

cursor = db.cursor()
cur = db.cursor()
# this is the query we will be making

print("Infant Details with median death rates from 2000 to 2015")
query = "SELECT LOWER(country.cshort),infant_new.imedian FROM country INNER JOIN infant_new ON country.cid = infant_new.cid"
#params=(did,year)
# execute the query   ,params
cur.execute(query)
# retrieve the whole result set
rows= cur.fetchall()
json_output = json.dumps(rows)
filename = 'infantMedian.json'
f = open(filename,'w+')
f.write(json_output)
f.close()

