import MySQLdb
import pandas as pd 
import numpy as np 
import matplotlib.pyplot as plt

# Connect the database
db = MySQLdb.connect(host="localhost",
                     user="root",
                     passwd="shwetha",
                     db="mortality")

cursor = db.cursor()

cur = db.cursor()

# this is the query we will be making
query="SELECT dname FROM disease_rate c1,disease p WHERE year=2000 LIMIT 5 ";
# execute the query
cur.execute(query)
# retrieve the whole result set
rows= cur.fetchall()
query1="SELECT `rate_of_deaths` FROM `disease_rate` WHERE `year`= 2000 LIMIT 5"
cur.execute(query1)
rows1=cur.fetchall()
plt.pie(rows1,labels=rows,autopct='%0.0f%%',shadow=True,startangle=0)
plt.axis('equal')
plt.title('No of deaths based on Year 2000')
plt.legend()
plt.show()
