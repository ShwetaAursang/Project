import MySQLdb
import pandas as pd 
import numpy as np 
import matplotlib.pyplot as plt

# Connect the database
db = MySQLdb.connect(host="localhost",
                     user="root",
                     passwd="shwetha",
                     db="mortality")

cursor = db.cursor()

# Execute SQL select statement
sql="SELECT `CountryName`,`Preterm`,`Pertussis`,`Intrapartum`,`Sepsis` FROM `under5` WHERE `Year`= 2000 LIMIT 50 "
cursor.execute(sql)
rows=cursor.fetchall()
#Transforming data into DataFrames
df=pd.DataFrame([[j for j in i] for i in rows])
ypos=df.groupby(df[3])[3].count()

values= [ypos[1],ypos[2],ypos[3],ypos[4],ypos[5],ypos[6],ypos[7],ypos[8],ypos[9],ypos[10],ypos[11],ypos[12],ypos[13],ypos[14]]

objects=["Preterm","Pertussis","Intrapartum","Sepsis","Tetanus","Congenital","Pneumonia","Diarrhoea","Malaria","Adis","Measies","Injury","Meningitis","Other"]

count=np.arange(len(objects))



#bar graph 
plt.bar(count,values,align='center')
plt.xticks(count,objects)
plt.xlabel("Dieases Name")
plt.ylabel("Year")
plt.title('Number of death rates of under-five children for diseases')
plt.show()



# Close the connection
db.close()
