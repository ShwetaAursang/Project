import MySQLdb
import pandas as pd 
import numpy as np 
import json
import matplotlib.pyplot as plt
# Connect
db = MySQLdb.connect(host="localhost",
                     user="root",
                     passwd="shwetha",
                     db="mortality")

cursor = db.cursor()
cur = db.cursor()
# this is the query we will be making

print("Under five children Details with lower death rates from 2000 to 2015")
year=raw_input("Enter a year")
query = "SELECT LOWER(country.CountryName),under_5_new.ulower FROM country INNER JOIN under_5_new ON country.cid = under_5_new.cid WHERE under_5_new.year=%s"% (year)
#params=(did,year)
# execute the query   ,params
cur.execute(query)
# retrieve the whole result set
rows= cur.fetchall()
json_output = json.dumps(rows)
filename = 'under5lower.json'
f = open(filename,'w+')
f.write(json_output)
f.close()

